<?php 
	$servidor = 'localhost';
	$bd = 'fatec';
	$usuario = 'admin'; 
	$senha = '123';
?>
