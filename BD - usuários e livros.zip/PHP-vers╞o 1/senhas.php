<?php 
	$servidor = 'localhost';
	$bd = 'fatec';
	$usuario = 'anv'; 
	$senha = 'f@tek';
?>
