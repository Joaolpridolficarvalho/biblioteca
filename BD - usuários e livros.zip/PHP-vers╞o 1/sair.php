<?php

$arq1="login.html";

$_SESSION['usuarioDigitado'] = '';
$_SESSION['senhaDigitada'] = '';
$usuarioDigitado = '';
$senhaDigitada = '';

session_unset();
session_destroy();

header("Location: $arq1");





?>